import axios from 'axios'


export const source_data =()=>
    {
        return axios.get("/location_info",{params:{}})
            .then(res=>{
                return res.data
            })

    }

export const student_info =()=>
{
    return axios.get("/student_info")
        .then(res=>{
            return res.data
        })

}

export const destination_data =()=>
{
    return axios.get("/destination_data")
        .then(res=>{
            return res.data
        })

}