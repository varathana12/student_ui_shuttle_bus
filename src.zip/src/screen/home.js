import React from 'react';
import '../component/style.css'

import {PrimaryButton,SourceSelect,DestinationSelect,DatePickers,CircularIndeterminate} from '../root'
import Layout from './layout'
import {connect} from 'react-redux'
import {submitBooking,sourceData,resetState,chageTitleHeader} from "../actions";
import {source_data} from "../api";
import BasicDatePicker from '../component/date_md'
import {withRouter} from 'react-router-dom'
class Home extends React.Component {

    state={
        loading_submit:false,
        style:{kk:4,name:"rathana"}
    }

    onSubmit(){
        const {booking_data,submitBooking,reset,history,title} = this.props;
        const {source, destination,date} = booking_data;

        if(source && destination && date){
            this.setState({loading_submit:true, style:{opacity:0.4, pointerEvents:"none"}})
            source_data().then(res =>{
                this.setState({loading_submit:false,style:{}})
                reset()
                history.push('/student/history')
                title("history")

            })
        }
        else{
            console.log(false)

        }

        submitBooking(true)

    }
    componentDidMount(){
        const {source} = this.props;
        source_data().then(data=>{
            console.log(data)
            source(data)
        })
    }

    render() {
        const {loading_submit,style} = this.state
        return (
           <Layout>
                <span>
                    <div hidden={!loading_submit}><CircularIndeterminate /></div>

                    <div style={this.state.style}>
                    <div style={{textAlign:"center"}}>
                        <h1 style={styles.header}>vKIRIROM<br/> SHUTTLE BUS</h1>
                    </div>
                    <form autoComplete="off">
                        <SourceSelect/>
                        <DestinationSelect/>
                        <BasicDatePicker/>
                        <PrimaryButton onSubmit={this.onSubmit.bind(this)}/>
                    </form>
                </div>
                </span>
            </Layout>
        );
    }
}
var styles ={
    header:{
        color:"rgba(0, 0, 0, 0.54)",
        marginAfter:0

    }
}
const mapDispatchToProps = dispatch => {
    return {
        submitBooking: status => (dispatch(submitBooking(status))),
        source: data =>(dispatch(sourceData(data))),
        reset:()=>(dispatch(resetState())),
        title:title=>(dispatch(chageTitleHeader(title)))

    }
}
const mapStateToProps =state =>{
    return {booking_data:
            {source:state.source,destination:state.destination,date:state.date}
    }
}

export default connect(mapStateToProps,mapDispatchToProps)(withRouter(Home));
