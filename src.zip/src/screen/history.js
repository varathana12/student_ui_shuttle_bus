import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from 'material-ui/styles';
import Layout from './layout'
import ExpansionPanel, {
    ExpansionPanelDetails,
    ExpansionPanelSummary,
} from 'material-ui/ExpansionPanel';
import Typography from 'material-ui/Typography';
import ExpandMoreIcon from 'material-ui-icons/ExpandMore';
import {SimpleTable} from '../root'
const styles = theme => ({
    root: {
        flexGrow: 1,
        marginTop:31
    },
    heading: {
        fontSize: theme.typography.pxToRem(15),
        flexBasis: '33.33%',
        flexShrink: 0,
    },
    secondaryHeading: {
        fontSize: theme.typography.pxToRem(15),
        color: theme.palette.text.secondary,
    },
    Typography_expand:{
        width:"100%"
    }

});

class History extends React.Component {
    state = {
        expanded: null,
    };

    handleChange = panel => (event, expanded) => {
        this.setState({
            expanded: expanded ? panel : false,
        });
    };

    render() {
        const { classes } = this.props;
        const { expanded } = this.state;

        return (
            <Layout>
            <div className={classes.root}>

                {
                    [1, 2, 3, 4, 5, 6,7,8,9,10,11,12].map((item) => {
                        return (
                            <ExpansionPanel key={item} expanded={expanded === 'panel'+item} onChange={this.handleChange('panel'+item)}>
                                <ExpansionPanelSummary expandIcon={<ExpandMoreIcon />}>
                                    <table className="table_expand">
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <Typography className={classes.heading}>Phnom Penh</Typography>
                                                </td>
                                                <td>
                                                    <Typography className={classes.secondaryHeading}>2018/03/12</Typography>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </ExpansionPanelSummary>
                                <ExpansionPanelDetails>
                                    <Typography style={{width:"100%"}}>
                                        <SimpleTable/>
                                    </Typography>
                                </ExpansionPanelDetails>
                            </ExpansionPanel>
                        )
                        }
                    )
                }
            </div>
            </Layout>
        );
    }
}

History.propTypes = {
    classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(History);