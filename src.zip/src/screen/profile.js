import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from 'material-ui/styles';
import { withTheme } from 'material-ui/styles';
import {SimpleMediaCard,ImageAvatars} from '../root'
import {student_info} from "../api";

const styles = theme => ({
    root:{
        marginBottom:66
    },
    profile: {
        height:200,
    },


});

class Profile extends React.Component {
    state={
        student_info:{}
    }
    componentDidMount(){
        student_info().then(res=>{
            console.log(res)
            this.setState({student_info:res});
        })
    }

    render() {
        const { classes } = this.props;
        const {primary} = this.props.theme.palette
        return (
            <div className={classes.root}>
            <div className={classes.profile} style={{backgroundColor:primary.main}}>
                <ImageAvatars image={this.state.profile}/>
            </div>
                <SimpleMediaCard student={this.state}/>
            </div>


        );
    }
}

Profile.propTypes = {
    classes: PropTypes.object.isRequired,
};

export default withTheme()(withStyles(styles)(Profile));