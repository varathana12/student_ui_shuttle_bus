export const CHANGE_TILTEL_HEADER = "CHANGE_TITTLE_HEADER"
export const HIDE_APP_BAR = "HIDE_APP_BAR"
export const SELECT_DESTINATION = "SELECT_DESTINATION"
export const SELECT_SOURCE = "SELECT_SOURCE"
export const SELECT_DATE = "SELECT_DATE"
export const SUBMIT_BOOKING = "SUBMIT_BOOKING"

/* -------------------- data ----------------------*/
export const SOURCE_DATA = "SOURCE_DATA"
export const DESTINATION_DATA = "DESTINATION_DATA"
export const STUDENT_INFO = "STUDENT_INFO";


/*---------------------- reset --------------------*/

export const RESET_STATE = "RESET_STATE";