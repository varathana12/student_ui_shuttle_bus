export const HOME = "Home"
export const HISTORY = "History"
export const PROFILE = "Profile"