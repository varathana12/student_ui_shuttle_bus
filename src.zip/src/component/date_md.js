import React, { Fragment, PureComponent } from 'react';
import { DatePicker } from 'material-ui-pickers';
import MomentUtils from 'material-ui-pickers/utils/moment-utils';
import MuiPickersUtilsProvider from 'material-ui-pickers/utils/MuiPickersUtilsProvider';
import {selectDate} from "../actions";
import {init_min_date,init_max_date} from "../init";
import {connect} from 'react-redux'
import 'material-design-icons/iconfont/material-icons.css'
class BasicDatePicker extends PureComponent {
    state = {
        selectedDate: '',
    }

    handleDateChange = (date) => {

        const {selectDate} = this.props;
        selectDate(date)

    }

    render() {
        const { date } = this.props;
        console.log(init_max_date())
        return (
            <Fragment>
                    <MuiPickersUtilsProvider utils={MomentUtils} >
                    <DatePicker
                        label="Departure Date"
                        value={date}
                        onChange={this.handleDateChange}
                        animateYearScrolling={true}
                        autoOk={true}
                        className={"date_picker"}
                        format={"DD/MM/YYYY"}
                        minDate={init_min_date()}
                        maxDate={init_max_date()}
                        shouldDisableDate={function (date) {
                            if(date.day() === 5 || date.day() === 6){
                                return false
                            }
                            return true
                        }}
                    />
                    </MuiPickersUtilsProvider>
            </Fragment>
        );
    }
}
const mapDispatchToProps = dispatch =>{
    return {
        selectDate: date =>(dispatch(selectDate(date)))
    }
}
const mapStateToProps = state =>{
    return {
        date:state.date,
        isSubmit:state.isSubmit
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(BasicDatePicker)