import React from 'react';
import TextField from 'material-ui/TextField';
import {selectDate} from "../actions";
import {connect} from 'react-redux'
import {student_info} from "../api";

class DatePickers extends React.Component{
    state ={
        date:'',
        required:true
    }
    onChange(event){
        const {selectDate} = this.props
        const {value} = event.target
        selectDate(value)
        this.setState({required: value ? false : true})
    }
    componentWillMount(){
        const {date} = this.props
        this.setState({date,required :date ? false : true})
    }
    componentDidMount(){

    }

    render(){
        const {isSubmit} = this.props
        const {required} = this.state
        return(
            <div style={{marginBottom:20}}>
                <TextField
                    error={required && isSubmit}
                    id="date"
                    label="Departure Date"
                    type="date"
                    fullWidth={true}
                    defaultValue={this.state.date}
                    className={"date_departure"}
                    onChange={this.onChange.bind(this)}
                    helperText={required && isSubmit ? "*required" :"" }

                />
            </div>
        )
    }
}

const mapDispatchToProps = dispatch =>{
    return {
        selectDate: date =>(dispatch(selectDate(date)))
    }
}
const mapStateToProps = state =>{
    return {
        date:state.date,
        isSubmit:state.isSubmit
    }
}

export default connect(mapStateToProps,mapDispatchToProps)(DatePickers);

