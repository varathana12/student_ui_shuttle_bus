import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from 'material-ui/styles';
import Table, { TableBody, TableCell, TableRow } from 'material-ui/Table';

const styles = theme => ({
    root: {
        width: '100%',
        marginTop: theme.spacing.unit * 3,
        overflowX: 'auto',
    },
    table: {
    },
});

let id = 0;
function createData(name, calories, fat, carbs, protein) {
    id += 1;
    return { id, name, calories, fat, carbs, protein };
}

const data = [
    createData('Time', "8:00 am"),
    createData('Source', "Kirirom"),
    createData('Destination', "Phnom Penh"),
    createData('Amount', "1"),
    createData('Bus Model', "Ssungyong"),
    createData('Plate Number', "2A-234D"),
    createData('Driver', "Mr Heng"),
];

function SimpleTable(props) {
    const { classes } = props;

    return (

            <Table className="table_cl">
                <TableBody>
                    {data.map(n => {
                        return (
                            <TableRow key={n.id}>
                                <TableCell><span style={{fontWeight:"bold"}}>{n.name}</span></TableCell>
                                <TableCell numeric><span style={{fontWeight:"bold",fontSize:20,paddingRight:5}}>:</span>{n.calories}</TableCell>

                            </TableRow>
                        );
                    })}
                </TableBody>
            </Table>
    );
}

SimpleTable.propTypes = {
    classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(SimpleTable);