import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from 'material-ui/styles';
import List, { ListItem, ListItemText,ListItemIcon } from 'material-ui/List';
import EmailIcon from 'material-ui-icons/Email';
import PhoneIcon from 'material-ui-icons/Phone';
import SchoolIcon from 'material-ui-icons/School';
import DirectionBusIcon from 'material-ui-icons/DirectionsBus'
const styles = theme => ({
    root: {
        width: '100%',
        backgroundColor: theme.palette.background.paper,
    },
});

function FolderList(props) {
    const { classes,student } = props;
    const {student_info} = student
    return (
        <div className={classes.root}>
            <List>
                <ListItem button>
                        <ListItemIcon >
                        <EmailIcon />
                        </ListItemIcon>
                    <ListItemText primary={student_info.email} secondary="email" />
                </ListItem>
                <ListItem button>
                    <ListItemIcon>
                        <PhoneIcon />
                    </ListItemIcon>
                    <ListItemText primary={student_info.phone? student_info.phone : "Unknown"} secondary="phone number" />
                </ListItem>
                <ListItem button>
                    <ListItemIcon>
                        <SchoolIcon />
                    </ListItemIcon>
                    <ListItemText primary={"Batch "+student_info.batch} secondary="generation" />
                </ListItem>
                <ListItem button>
                    <ListItemIcon>
                        <DirectionBusIcon />
                    </ListItemIcon>
                    <ListItemText primary={student_info.ticket+" Tickets"} secondary="ticket remaining" />
                </ListItem>

            </List>
        </div>
    );
}

FolderList.propTypes = {
    classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(FolderList);