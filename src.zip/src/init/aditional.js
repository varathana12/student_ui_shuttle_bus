
export const deleteElementLocation = (collection,element)=>{
     var data =[];
     collection.map(item=>{
        if(item.location_id != element)
            data.push(item)
    })
    return data
}



