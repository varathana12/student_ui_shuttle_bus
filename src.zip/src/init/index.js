const path = window.location.pathname
export const init_status_app_bar = path === "/student/profile" ? true : false;
let array = path.split("/")
export const init_route_name = array[array.length-1]



export const date_now = ()=>{
    let date = new Date();

    return date.getFullYear()+"-"+(date.getMonth()+1)+"-"+date.getDate()
}

export const init_date = ()=>{
    let date = new Date(init_min_date());
    while(true){
        if(date.getDay()<5){
            date.setDate(date.getDate()+1)
        }
        else{
            break
        }
    }
    return date.getFullYear()+"-"+(date.getMonth()+1)+"-"+date.getDate()
}

export const init_max_date = ()=>{
    let date = new Date(init_date());
    date.setDate(date.getDate()+2)
    return date.getFullYear()+"-"+(date.getMonth()+1)+"-"+date.getDate()
}

export const init_min_date =()=>{
    let date = new Date(date_now());
    date.setDate(date.getDate()+2)
    return date.getFullYear()+"-"+(date.getMonth()+1)+"-"+date.getDate()
}
